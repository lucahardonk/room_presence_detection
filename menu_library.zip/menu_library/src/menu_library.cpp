#include "menu_library.h"

Menu::Menu()
{

  Serial.begin(115200);

}

void Menu::readSerial()
{ //function to read from Serial 

  while(Serial.available() > 0) 
  {
      
    incomingByte = Serial.read();
    tot += incomingByte;
    delay(5);

  }

  if(tot != "")
  {

    tot.trim();
      
    switch(atoi(tot.c_str()))
    { //choose between the 6 credentials

      case 1:
        tot = "";
        Serial.println("SSID");
        config_credential = true;
        insertCredential("ssid", 1);
      break;

      case 2:
        tot = "";
        Serial.println("PASSWORD WIFI");
        config_credential = true;
        insertCredential("password wifi", 2);
      break;

      case 3:
        tot = "";
        Serial.println("ID SERVER MQTT");
        config_credential = true;
        insertCredential("ID server mqtt", 3);
      break;

      case 4:
        tot = "";
        Serial.println("USERNAME MQTT");
        config_credential = true;
        insertCredential("username mqtt", 4);
      break;

      case 5:
        tot = "";
        Serial.println("PASSWORD MQTT");
        config_credential = true;
        insertCredential("password mqtt", 5);
      break;

      case 6:
        tot = "";
        Serial.println("ID CLIENT");
        config_credential = true;
        insertCredential("ID client", 6);
      break;

      default:
        Serial.println("Error! Number between 1-6.");
        delay(2000);
        tot = "";
        entered_menu = true;
        menu();
      break;
      
    }
    
  }

}

void Menu::insertCredential(String credential, int code)
{ //function to read rhe credential and save it to the EEPROM

  String tmp;

  Serial.print("Insert credential or press reset to return to the menu: ");

  while(config_credential && !confirm)
  {

    while(Serial.available() > 0) 
    {
        
      incomingByte = Serial.read();
      tot += incomingByte;
      delay(5);

    }

    if(tot != "")
    {

      tot.trim();
      Serial.println(tot);
      tmp = tot;
      confirm = true;
      config_credential = false;
      tot = "";

    }
    
  } 

  //confirm the credential
  Serial.print("Confirm? (Y for yes, N for no): ");

  while(confirm)
  {
  
    while(Serial.available() > 0) 
    {
        
      incomingByte = Serial.read();
      tot += incomingByte;
      delay(5);

    }

    if(tot != "")
    {

      tot.trim();
      Serial.println(tot);
      if(tot == "Y")
      {

        switch(code)
        { //allocate the EEPROM addresses

          case 1:
            updateStringToEEPROM(0, 99, tmp);
            credentials_str[0] = tmp;
            credentials_bool[0] = true;
          break;

          case 2:
            updateStringToEEPROM(100, 199, tmp);
            credentials_str[1] = tmp;
            credentials_bool[1] = true;
          break;

          case 3:
            updateStringToEEPROM(200, 299, tmp);
            credentials_str[2] = tmp;
            credentials_bool[2] = true;
          break;

          case 4:
            updateStringToEEPROM(300, 399, tmp);
            credentials_str[3] = tmp;
            credentials_bool[3] = true;
          break;

          case 5:
            updateStringToEEPROM(400, 499, tmp);
            credentials_str[4] = tmp;
            credentials_bool[4] = true;
          break;

          case 6:
            updateStringToEEPROM(500, 599, tmp);
            credentials_str[5] = tmp;
            credentials_bool[5] = true;
          break;

        }

        confirm = false;
        tot = "";
        menu();

      }

      else if(tot == "N")
      {

        confirm = false;
        tot = "";
        config_credential = true;
        confirm = false;
        insertCredential(credential, code);

      }

      else
      {

        Serial.println("Error!");
        confirm = false;
        tot = "";
        insertCredential(credential, code);

      }
      
    } 

  }

}

void Menu::checkCredential(String credential, int code)
{ //function to check if a credential is fill or not

  if(code < 1 || code > 6) 
  {
    
    Serial.println("Error! Number between 1-6.");
    menu();

  }

  else
  {

    if(!credentials_bool[code - 1]) 
    {
          
      Serial.print(credential);
      Serial.println(credentials_str[code - 1]);

    }

    else if(credentials_bool[code - 1])
    {

      Serial.print(credential);
      Serial.println(credentials_str[code - 1]);

    }

  }

  return credentials_bool[code - 1];

}

void Menu::printMenu()
{ //function to print the menu

  Serial.println("\n");
  Serial.println("Welcome to the menu! Enter Esc for exit when all the credentials have been configured.");

  checkCredential("1)ssid: ", 1);
  checkCredential("2)passowrd wifi: ", 2);
  checkCredential("3)IP server mqtt: ", 3);
  checkCredential("4)username mqtt: ", 4);
  checkCredential("5)password mqtt: ", 5);
  checkCredential("6)client ID: ", 6);

  n_credential = 0;

  for(int i = 0; i < CREDENTIALS_N; i++) if(credentials_bool[i]) n_credential++;

  Serial.print("Enter a code between 1-6: ");

}

void Menu::menu()
{ //print and choose from the menu

    printMenu();

    while(entered_menu)
    { 

        while(Serial.available() > 0) 
        {
        
        incomingByte = Serial.read();
        tot += incomingByte;
        delay(5);

        }

        if(tot != "")
        {

        tot.trim();
        
        if(tot == "Esc" && n_credential == 6)
        { //exit from the menu

            Serial.println("Exiting the menu...");
            delay(1000);
            tot = "";
            entered_menu = false;

        }

        else if(tot == "Esc" && n_credential != 6)
        {

            Serial.println("Error! There are credentials to be set.");
            delay(1000);
            tot = "";
            menu();

        }

        else{ readSerial(); }
        
        tot = "";
        
        } 
    }
    setup();

}

void Menu::resetEEPROM()
{ //function for fill the EEPROM with the jolly

  Serial.println("Resetting EEPROM...");

  for(int i = 0; i < 600; i++) EEPROM.update(i, jolly);

}

void Menu::printEEPROM()
{ //function to print the entire EEPROM
  
  String result;
  char byte;

  for(int i = 0; i < 600; i++) 
  {

    byte = EEPROM.read(i);
    result += byte;
  
  }

  Serial.println(result);

}

void Menu::updateStringToEEPROM(int addr_start, int addr_end, const String &strToWrite)
{ //function to write a string in the EEPROM
  for(int a = addr_start; a < addr_end; a++) EEPROM.update(a, jolly);

  for(int a = 0; a < strToWrite.length(); a++) EEPROM.update(addr_start + a, strToWrite[a]);

}

void Menu::startMenu()
{ //function to start the possibility of entering the menu

  Serial.begin(115200);

  Serial.println("Write menu to enter the menu or reset to reset the EEPROM: ");

  i = 8;
    
  while(i > 0 && !entered_menu)
  {

    Serial.println(i);

    while (Serial.available() > 0) 
    {
        
      m = Serial.read();
      menuStr += m;
      delay(5);

    }

    if(menuStr != "")
    {

      menuStr.trim();

      if(menuStr == "menu")
      {

        Serial.println("Entering the menu...");
        delay(1000);
        entered_menu = true;
        menuStr = "";
        menu();

      }

      else if(menuStr == "reset")
      {

        entered_menu = true;
        resetEEPROM();

      }

      menuStr = "";
      
    }

    i--;

    if(i == 0) entered_menu = true;

    delay(1000);

  }

  printEEPROM();

}
