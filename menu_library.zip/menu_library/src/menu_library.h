#ifndef MENU_LIBRARY_H
#define MENU_LIBRARY_H

#include <EEPROM.h>
#include <Arduino.h>

#define CREDENTIALS_N 6 //numer of possible credentials 

class Menu
{

private:

    int n_credential = 0; //check the number of credentials setted
    char jolly = '~'; //character to fill the EEPROM
    char incomingByte; //single byte from read()
    String tot; //entire string from read()
    String menuStr; //string from read() to enter the menu
    char m; //single character from read() to enter the menu
    int i = 8; //seconds to enter the menu
    bool entered_menu = false; //check if we are in the menu or not
    bool config_credential = false; //check if we are in the configuration of the credentials or not
    bool confirm = false; //check if we are in the confirm part or not
    String credentials_str[CREDENTIALS_N] = {}; //it contains the credential inserted
    bool credentials_bool[CREDENTIALS_N] = {
                                            false,
                                            false,
                                            false,
                                            false,
                                            false,
                                            false
                                        }; //it contains true in the index/es associated to the credential/s inserted 

public:
    Menu();
    void readSerial(); //function to read from Serial 
    void insertCredential(String credential, int code); //function to read rhe credential and save it to the EEPROM
    void checkCredential(String credential, int code); //function to check if a credential is fill or not
    void printMenu(); //function to print the menu
    void menu(); //print and choose from the menu
    void resetEEPROM(); //function for fill the EEPROM with the jolly
    void printEEPROM(); //function to print the entire EEPROM
    void updateStringToEEPROM(int addr_start, int addr_end, const String &strToWrite); //function to write a string in the EEPROM
    void startMenu(); //function to start the possibility of entering the menu

};

#endif  //MENU_LIBRARY_H
